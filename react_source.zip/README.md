# Cinematic Duo Portfolio

A high-performance, immersive portfolio website for **Karl Benjamin R. Bughaw** and **Jhanric Hanamichi Pablo**. Built with Next.js 16, Framer Motion, and WebGL to showcase technical synergy between system architecture and creative frontend design.

## 🚀 Key Features

- **Dynamic Repository Archive:** Real-time synchronization with GitHub APIs to showcase live projects via a custom "Agent Plan" UI.
- **Cinematic Experience:** Multi-layered parallax motion, custom WebGL shaders (Spooky Smoke, Raycast Backgrounds), and atmospheric "Background Beams."
- **Professional Identity:** Integrated GitHub avatars, status indicators, and high-end 3D profile cards.
- **Terminal Interactivity:** A developer-focused CLI-style contact interface and draggable system monitoring elements.
- **Optimized Performance:** Fully optimized for Turbopack with instant page transitions and zero-interruption navigation.

## 🛠 Tech Stack

- **Framework:** Next.js 16 (App Router)
- **Styling:** Tailwind CSS + Vanilla CSS
- **Animations:** Framer Motion + GSAP
- **Graphics:** WebGL / Three.js (via Unicorn Studio)
- **Deployment:** Vercel

## 📦 Getting Started

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Run the development server:**
   ```bash
   npm run dev
   ```

3. **Build for production:**
   ```bash
   npm run build
   ```

## 🤝 The Duo

- **Karl Benjamin (Golgrax):** System Architect & Backend Specialist.
- **Jhanric (jhanric-pablo):** Creative Developer & UI/UX Specialist.

---
Built with mathematical precision and artistic vision.
