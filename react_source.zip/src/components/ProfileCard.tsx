"use client";
import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useMotionTemplate, Variants, TargetAndTransition } from 'framer-motion';
import { FolderOpen } from 'lucide-react';
import Image from 'next/image';

const layerVariants: Variants = {
  rest: { 
    x: 0, 
    y: 0, 
    scale: 1, 
    rotate: 0,
    opacity: 1,
    transition: { duration: 0.3, ease: "backOut" }
  },
  hover: (custom: TargetAndTransition) => ({
    ...custom,
    transition: { duration: 0.4, ease: [0.34, 1.56, 0.64, 1] }
  })
};

interface ProfileCardProps {
  name: string;
  role: string;
  avatar: string;
  github: string;
  alias: string[];
  bio: string;
}

export const ProfileCard: React.FC<ProfileCardProps> = ({ 
  name, role, avatar, github, alias, bio 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      className="group relative w-full max-w-[400px] mx-auto bg-surface border-bionic shadow-bionic p-8"
    >
       <div className="absolute top-0 right-0 w-16 h-16 bg-caution-stripes opacity-10 -rotate-45 translate-x-8 -translate-y-8" />
       
       <div className="flex flex-col items-center">
          <div className="w-full aspect-square border-bionic shadow-bionic-accent mb-8 relative group/avatar bg-ink-dark overflow-hidden">
             <Image src={avatar} alt={name} fill sizes="300px" className="object-cover" />
             <div className="absolute top-4 left-4 bg-accent-red text-surface px-3 py-1 text-[12px] font-black uppercase tracking-widest border-2 border-ink-dark">
               UNIT_{name.split(' ')[0]}
             </div>
          </div>

          <div className="w-full space-y-4 mb-8 border-l-[8px] border-ink-dark pl-6">
             <h3 className="text-4xl font-black text-ink-dark uppercase tracking-tighter leading-none">{name}</h3>
             <div className="inline-block bg-accent-red text-surface px-3 py-1 text-bionic-label font-black">
                {role}
             </div>
          </div>

          <div className="w-full p-4 border-2 border-ink-dark bg-ink-dark/5 font-asix text-[12px] leading-tight text-ink-dark mb-8 uppercase font-black tracking-tight">
             &quot;{bio.substring(0, 150)}...&quot;
          </div>

          <div className="w-full flex flex-wrap gap-2 mb-8">
             {alias.map(a => (
               <span key={a} className="bg-ink-dark text-surface px-2 py-1 text-[10px] font-asix font-black uppercase tracking-widest">#{a}</span>
             ))}
          </div>

          <a 
            href={github} 
            target="_blank" 
            className="w-full bionic-button flex items-center justify-center gap-3 text-bionic-label"
          >
             <FolderOpen size={22} strokeWidth={3} />
             <span>ACCESS_DATA</span>
          </a>
       </div>
    </motion.div>
  );
};
