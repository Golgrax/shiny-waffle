"use client";

import React, { useState } from "react";
import {
  CheckCircle2,
  Circle,
  CircleAlert,
  CircleDotDashed,
  CircleX,
  ExternalLink,
} from "lucide-react";
import { GithubIcon } from "@/components/icons";
import { motion, AnimatePresence, LayoutGroup } from "framer-motion";

// Type definitions
export interface Subtask {
  id: string;
  title: string;
  description: string;
  status: "completed" | "in-progress" | "pending" | "need-help" | "failed";
  priority: string;
  tools?: string[]; 
}

export interface Task {
  id: string;
  title: string;
  description: string;
  status: "completed" | "in-progress" | "pending" | "need-help" | "failed";
  priority: string;
  level: number;
  dependencies: string[];
  subtasks: Subtask[];
  url?: string;
}

export default function AgentPlan({ initialTasks }: { initialTasks: Task[] }) {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [expandedTasks, setExpandedTasks] = useState<string[]>(initialTasks.slice(0, 1).map(t => t.id));
  
  const toggleTaskExpansion = (taskId: string) => {
    setExpandedTasks((prev) =>
      prev.includes(taskId)
        ? prev.filter((id) => id !== taskId)
        : [...prev, taskId],
    );
  };

  return (
    <div className="bg-surface border-bionic overflow-hidden shadow-bionic mt-8 mb-8">
      <LayoutGroup>
        <div className="p-4 bg-ink-dark/5">
          <ul className="space-y-4">
            {tasks.map((task) => {
              const isExpanded = expandedTasks.includes(task.id);
              return (
                <motion.li
                  key={task.id}
                  className="group/item"
                >
                  <motion.div 
                    className="flex items-center px-4 py-3 border-2 border-ink-dark bg-surface hover:border-accent-red transition-all cursor-pointer"
                    onClick={() => toggleTaskExpansion(task.id)}
                  >
                    <div className="mr-4 flex-shrink-0">
                      {task.status === "completed" ? (
                        <CheckCircle2 className="h-6 w-6 text-accent-red" />
                      ) : (
                        <Circle className="h-6 w-6 text-ink-dark/20" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-4">
                        <span className="text-sm font-black text-ink-dark uppercase truncate tracking-tight">
                          {task.title}
                        </span>
                        <div className="flex items-center gap-2">
                          <span
                            className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 border-2 ${
                              task.status === "completed" ? "bg-accent-red text-white border-accent-red" :
                              "bg-ink-dark text-white border-ink-dark"
                            }`}
                          >
                            {task.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  </motion.div>

                  <AnimatePresence>
                    {isExpanded && task.subtasks.length > 0 && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="ml-6 mt-2 pl-6 border-l-[6px] border-ink-dark/10 space-y-4 py-4"
                      >
                        {task.subtasks.map((subtask) => (
                          <div key={subtask.id} className="relative">
                             <div className="flex items-center gap-3 mb-1">
                                <div className="w-3 h-3 bg-accent-red border border-ink-dark" />
                                <span className="text-[10px] text-ink-dark font-black uppercase tracking-tight">{subtask.title}</span>
                             </div>
                             <p className="text-[10px] text-ink-dark/60 ml-6 leading-tight font-mono uppercase font-black">
                                {subtask.description}
                             </p>
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.li>
              );
            })}
          </ul>
        </div>
      </LayoutGroup>
    </div>
  );
}
