"use client";
import React, { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

export const BackgroundBeams = ({ className }: { className?: string }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <div
      ref={containerRef}
      className={cn(
        "absolute inset-0 h-full w-full [mask-image:radial-gradient(ellipse_at_center,transparent_20%,black)] pointer-events-none overflow-hidden",
        className
      )}
    >
      <div className="absolute inset-0 z-0">
         {[...Array(20)].map((_, i) => (
           <Beam key={i} />
         ))}
      </div>
    </div>
  );
};

const Beam = () => {
  const beamRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const move = () => {
      if (!beamRef.current) return;
      const duration = Math.random() * 3 + 2;
      const delay = Math.random() * 5;
      const x = Math.random() * 100;
      const y = Math.random() * 100;
      
      beamRef.current.style.left = `${x}%`;
      beamRef.current.style.top = `${y}%`;
      beamRef.current.style.animationDuration = `${duration}s`;
      beamRef.current.style.animationDelay = `${delay}s`;
    };
    move();
  }, []);

  return (
    <div
      ref={beamRef}
      className="absolute h-px w-[100px] bg-gradient-to-r from-transparent via-orange-500 to-transparent opacity-20 animate-beam rotate-[35deg]"
    />
  );
};
