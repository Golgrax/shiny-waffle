"use client";
import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import dynamic from "next/dynamic";

const RaycastBg = dynamic(() => import("./raycast-animated-background").then(mod => mod.Component), { ssr: false });

export function BackgroundChassis() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll();

  // Parallax offsets for different holes
  const y1 = useTransform(scrollYProgress, [0, 1], [0, -400]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, 300]);
  const y3 = useTransform(scrollYProgress, [0, 1], [0, -600]);
  const y4 = useTransform(scrollYProgress, [0, 1], [0, 500]);
  const y5 = useTransform(scrollYProgress, [0, 1], [0, -200]);

  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
      {/* Lowest Layer: Animation */}
      <div className="absolute inset-0 z-[-2]">
        <RaycastBg />
      </div>
      
      {/* Middle Layer: Plain BG with Parallax SVG Mask */}
      <div className="absolute inset-0 z-[-1]">
        <svg className="w-full h-full" preserveAspectRatio="none">
          <defs>
            <mask id="industrialParallaxHoles">
              <rect width="100%" height="100%" fill="white" />
              {/* Parallaxing Rectangular Holes */}
              <motion.rect style={{ y: y1 }} x="5%" y="10%" width="150" height="200" fill="black" />
              <motion.rect style={{ y: y2 }} x="75%" y="5%" width="250" height="150" fill="black" />
              <motion.rect style={{ y: y3 }} x="40%" y="40%" width="180" height="180" fill="black" />
              <motion.rect style={{ y: y4 }} x="15%" y="70%" width="200" height="300" fill="black" />
              <motion.rect style={{ y: y5 }} x="80%" y="75%" width="300" height="200" fill="black" />
              <motion.rect style={{ y: y1 }} x="60%" y="20%" width="100" height="400" fill="black" />
            </mask>
          </defs>
          <rect width="100%" height="100%" fill="#f5f5f5" fillOpacity="0.75" mask="url(#industrialParallaxHoles)" />
        </svg>
      </div>

      {/* Decorative Sliding Sides (Optional but cool) */}
      <div className="absolute inset-0 z-[-1] opacity-10">
        <motion.div style={{ y: y1 }} className="absolute top-[10%] left-[5%] w-[150px] h-[200px] border-l-[10px] border-accent-red -skew-x-[60deg]" />
        <motion.div style={{ y: y2 }} className="absolute top-[5%] right-[25%] w-[250px] h-[150px] border-r-[10px] border-ink-dark skew-x-[60deg]" />
        <motion.div style={{ y: y3 }} className="absolute top-[40%] left-[40%] w-[180px] h-[180px] border-t-[10px] border-accent-red -skew-y-[60deg]" />
      </div>
    </div>
  );
}
