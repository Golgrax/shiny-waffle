"use client";
import React from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const navItems = [
  { name: "Home", href: "/" },
  { name: "About", href: "/about" },
  { name: "Skills", href: "/skills" },
  { name: "Projects", href: "/projects" },
  { name: "Contact", href: "/contact" },
];

export function Navbar() {
  const pathname = usePathname();

  return (
    <nav className="fixed top-0 left-0 right-0 z-[100] w-full bg-surface border-b-bionic border-ink-dark shadow-bionic flex items-center justify-between px-12 py-6">
      <div className="flex items-center gap-8">
        <div className="bg-accent-red text-white font-asix text-4xl px-8 py-3 border-r-bionic border-ink-dark -ml-12 -my-6">
          KJ
        </div>
        <div className="hidden md:block">
          <p className="text-4xl font-asix text-ink-dark leading-none uppercase tracking-tighter">DUO_PORTFOLIO</p>
          <p className="text-[10px] font-mono text-ink-dark/40 uppercase font-black tracking-widest mt-1">Northeastern_Cluster</p>
        </div>
      </div>

      <div className="flex items-center gap-1 md:gap-4">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "relative px-4 py-2 text-bionic-label transition-none border-[3px] border-transparent font-black",
                isActive ? "text-surface bg-ink-dark border-ink-dark" : "text-ink-dark border-transparent"
              )}
            >
              <span className="relative z-10">{item.name}</span>
            </Link>
          );
        })}
      </div>

      <div className="hidden lg:flex items-center gap-4">
        <div className="bg-ink-dark/5 px-6 py-3 border-l-bionic border-ink-dark -mr-8 -my-4 h-[72px] flex items-center">
           <div className="text-right">
              <p className="text-2xl font-asix text-ink-dark leading-none">A3</p>
              <p className="text-[8px] font-mono text-ink-dark/40 uppercase font-black">Core_Sys</p>
           </div>
        </div>
      </div>
    </nav>
  );
}
