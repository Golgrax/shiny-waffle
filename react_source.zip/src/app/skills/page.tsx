"use client";
import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { duoInfo } from "@/lib/data";
import { Code2, Layers, Wrench } from "lucide-react";
import { BackgroundChassis } from "@/components/ui/background-chassis";

export default function SkillsPage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"],
  });

  const y1 = useTransform(scrollYProgress, [0, 1], [0, -150]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const opacity = useTransform(scrollYProgress, [0, 0.1, 0.9, 1], [1, 1, 1, 0]);

  const categories = [
    { title: "Languages", icon: <Code2 size={24} />, skills: [...new Set([...duoInfo.karl.skills.languages, ...duoInfo.jhanric.skills.languages])] },
    { title: "Frameworks", icon: <Layers size={24} />, skills: [...new Set([...duoInfo.karl.skills.frameworks, ...duoInfo.jhanric.skills.frameworks])] },
    { title: "Tools", icon: <Wrench size={24} />, skills: [...new Set([...duoInfo.karl.skills.tools, ...duoInfo.jhanric.skills.tools])] }
  ];

  return (
    <main ref={containerRef} className="min-h-screen pt-60 pb-80 px-6 relative overflow-hidden">
      <BackgroundChassis />

      <div className="max-w-7xl mx-auto relative z-10 space-y-60">
        <motion.div style={{ opacity, y: y1 }} className="mb-40">
          <motion.h3 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="text-bionic-heading text-ink-dark"
          >
            <span className="text-selected-dark px-12">TECH</span> <br /> <span className="text-selected-red px-12 mt-4 inline-block">STACK</span>
          </motion.h3>
        </motion.div>

        <div className="mt-12 space-y-20">
          {categories.map((cat, idx) => (
            <div key={cat.title} className="w-full">
              <SkillCategorySection title={cat.title} icon={cat.icon} skills={cat.skills} delay={idx * 0.1} />
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}

function SkillCategorySection({ title, icon, skills, delay }: { title: string, icon: React.ReactNode, skills: string[], delay: number }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      className="p-12 md:p-16 border-bionic bg-surface shadow-bionic min-h-[500px] flex flex-col relative overflow-hidden group/cat"
    >
      <div className="absolute top-0 right-0 w-32 h-32 bg-caution-stripes opacity-10 -rotate-45 translate-x-16 -translate-y-16" />
      
      <div className="flex items-center justify-between mb-16 relative z-10">
        <div className="flex items-center gap-8">
           <div className="w-20 h-20 bg-ink-dark border-bionic border-accent-red flex items-center justify-center text-surface shadow-bionic-accent transition-none">
              {icon}
           </div>
           <div>
              <h4 className="text-selected-red font-asix text-[12px] uppercase tracking-[0.4em] mb-2 font-black px-2">CLUSTER_TYPE</h4>
              <p className="text-ink-dark font-asix text-5xl uppercase tracking-tighter leading-none">{title}</p>
           </div>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 relative z-10">
        {skills.map((skill) => (
          <div 
            key={skill}
            className="flex flex-col items-center gap-4 p-6 border-bionic bg-surface shadow-bionic transition-none group relative"
          >
            <img 
              src={`https://skillicons.dev/icons?i=${getIconSlug(skill)}`} 
              alt={skill} 
              className="w-10 h-10 md:w-14 md:h-14 grayscale" 
            />
            <div className="bg-box-gray !p-1 text-center">
              <span className="text-bionic-label text-ink-dark font-black px-2 py-0.5">{skill}</span>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function getIconSlug(skill: string): string {
  const map: Record<string, string> = {
    "Next.js": "nextjs",
    "TypeScript": "typescript",
    "JavaScript": "javascript",
    "Rust": "rust",
    "Python": "python",
    "C++": "cpp",
    "C": "c",
    "Java": "java",
    "Lua/Luau": "lua",
    "SQL": "mysql",
    "Bash": "bash",
    "Tailwind CSS": "tailwind",
    "React": "react",
    "Vue.js": "vue",
    "Three.js": "threejs",
    "Framer Motion": "framer",
    "Node.js": "nodejs",
    "Flask": "flask",
    "TensorFlow": "tensorflow",
    "PyTorch": "pytorch",
    "NumPy": "numpy",
    "Docker": "docker",
    "Git": "git",
    "Vim": "vim",
    "Figma": "figma",
    "MX Linux": "linux",
    "Debian": "debian",
    "Xcode": "apple",
    "GitHub": "github",
    "Discord": "discord",
  };
  return map[skill] || skill.toLowerCase().replace(/\s+/g, "");
}
