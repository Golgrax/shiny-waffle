"use client";
import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ProfileCard } from "@/components/ProfileCard";
import { duoInfo } from "@/lib/data";
import { Cpu, Globe, Zap, Sparkles } from "lucide-react";
import { BackgroundChassis } from "@/components/ui/background-chassis";

export default function AboutPage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"],
  });

  const y1 = useTransform(scrollYProgress, [0, 1], [0, -200]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [1, 1, 1, 0]);

  return (
    <main ref={containerRef} className="min-h-screen pt-60 pb-60 px-6 relative overflow-hidden">
      <BackgroundChassis />
      
      <div className="max-w-7xl mx-auto relative z-10 space-y-40">
        <motion.div style={{ opacity }} className="mb-40 text-center border-b-bionic border-ink-dark pb-40">
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-bionic-heading text-ink-dark"
          >
            <span className="text-selected-dark px-8">CORE</span> <br /> <span className="text-selected-red px-8 mt-4 inline-block">ARCHITECTS</span>
          </motion.h2>
          <div className="flex items-center justify-center gap-4 mt-12">
             <div className="h-6 w-24 bg-caution-stripes border-2 border-ink-dark" />
             <div className="bg-box-gray">
               <p className="text-bionic-label text-ink-dark px-4 py-1">
                  Merging deep logic with aesthetic vision
               </p>
             </div>
             <div className="h-6 w-24 bg-accent-red border-2 border-ink-dark" />
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-32 lg:gap-48 items-center mb-80 pt-20">
          <motion.div 
            style={{ y: y1 }}
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4 }}
            className="order-2 lg:order-1 relative"
          >
             <ProfileCard 
               name={duoInfo.karl.name}
               role={duoInfo.karl.role}
               avatar={duoInfo.karl.avatar}
               github={duoInfo.karl.socials.github}
               alias={duoInfo.karl.alias}
               bio={duoInfo.karl.bio}
             />
          </motion.div>
          <motion.div style={{ y: y2 }} className="order-1 lg:order-2 space-y-20">
             <AboutSection 
                icon={<Cpu size={32} />}
                title="Systems Engineering"
                subtitle="The Logical Core"
                desc="Karl specializes in high-throughput backend architectures and neural network integration. His focus is on the structural integrity and predictive logic that powers complex digital systems."
                tags={["RUST", "PYTHON", "LUA", "AI"]}
                color="accent"
             />
             <AboutSection 
                icon={<Zap size={32} />}
                title="Performance Logic"
                subtitle="Optimized Execution"
                desc="Building frameworks like Syqlorix to push the boundaries of Python speed using Rust-powered kernels. Precision in every line of code."
                tags={["SPEED", "HYBRID", "CORE", "KERNELS"]}
                color="accent"
             />
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-32 lg:gap-48 items-center border-t-bionic border-ink-dark pt-40">
          <motion.div style={{ y: y2 }} className="space-y-20">
             <AboutSection 
                icon={<Globe size={32} />}
                title="Creative Interface"
                subtitle="The Aesthetic Layer"
                desc="Jhanric crafts immersive digital experiences where every interaction feels natural. He focuses on the cinematic presentation of complex data and systems."
                tags={["NEXT.JS", "THREE.JS", "MOTION", "UX"]}
                color="dark"
             />
             <AboutSection 
                icon={<Sparkles size={32} />}
                title="Visual Narrative"
                subtitle="Storytelling through Code"
                desc="Merging motion design with frontend engineering to create websites that aren't just tools, but digital journeys. Every pixel has a purpose."
                tags={["CINEMATIC", "INTERACTIVE", "IMMERSIVE"]}
                color="dark"
             />
          </motion.div>
          <motion.div 
            style={{ y: y1 }}
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4 }}
            className="relative"
          >
             <ProfileCard 
                name={duoInfo.jhanric.name}
                role={duoInfo.jhanric.role}
                avatar={duoInfo.jhanric.avatar}
                github={duoInfo.jhanric.socials.github}
                alias={duoInfo.jhanric.alias}
                bio={duoInfo.jhanric.bio}
              />
          </motion.div>
        </div>
      </div>
    </main>
  );
}

function AboutSection({ icon, title, subtitle, desc, tags, color = "accent" }: { icon: React.ReactNode, title: string, subtitle: string, desc: string, tags: string[], color?: "accent" | "dark" }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="group"
    >
       <div className="flex items-center gap-8 mb-8">
          <div className={`w-20 h-20 bg-surface border-bionic flex items-center justify-center text-ink-dark transition-none ${color === "accent" ? "shadow-bionic-accent" : "shadow-bionic"}`}>
             {icon}
          </div>
          <div>
             <h4 className="text-4xl font-black text-ink-dark uppercase tracking-tighter leading-none">{title}</h4>
             <p className={`text-bionic-label mt-2 font-black tracking-widest ${color === "accent" ? "text-highlight-red" : "text-highlight-dark"}`}>{subtitle}</p>
          </div>
       </div>
       <div className="border-l-bionic border-ink-dark pl-8 mb-8">
         <div className="bg-box-gray">
           <p className="text-ink-dark text-sm md:text-lg leading-tight font-black uppercase">
              {desc}
           </p>
         </div>
       </div>
       <div className="flex flex-wrap gap-3 pl-8">
          {tags.map(tag => (
            <span key={tag} className="text-[10px] font-mono font-black text-surface bg-ink-dark px-4 py-1 uppercase tracking-widest border-2 border-ink-dark transition-none">{tag}</span>
          ))}
       </div>
    </motion.div>
  );
}
