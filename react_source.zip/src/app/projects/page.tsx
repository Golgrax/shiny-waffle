"use client";

import React, { useEffect, useState, useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Code2, Sparkles } from "lucide-react";
import AgentPlan, { Task } from "@/components/ui/agent-plan";
import { BackgroundChassis } from "@/components/ui/background-chassis";

interface GitHubRepo {
  id: number;
  name: string;
  description: string;
  html_url: string;
  stargazers_count: number;
  language: string;
  updated_at: string;
}

export default function ProjectsPage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"],
  });

  const y1 = useTransform(scrollYProgress, [0, 1], [0, -100]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, 100]);
  const opacity = useTransform(scrollYProgress, [0, 0.1, 0.9, 1], [1, 1, 1, 0]);

  const [karlRepos, setKarlRepos] = useState<Task[]>([]);
  const [jhanricRepos, setJhanricRepos] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchRepos() {
      try {
        const [karlRes, jhanricRes] = await Promise.all([
          fetch("https://api.github.com/users/Golgrax/repos?sort=updated&per_page=6"),
          fetch("https://api.github.com/users/jhanric-pablo/repos?sort=updated&per_page=6")
        ]);

        const karlData: GitHubRepo[] = await karlRes.json();
        const jhanricData: GitHubRepo[] = await jhanricRes.json();

        const transform = (repo: GitHubRepo): Task => ({
          id: repo.id.toString(),
          title: repo.name,
          description: repo.description || "No description provided.",
          status: "completed",
          priority: repo.stargazers_count > 10 ? "high" : "medium",
          level: 0,
          dependencies: [],
          url: repo.html_url,
          subtasks: [
            {
              id: `${repo.id}-1`,
              title: "Primary Stack",
              description: repo.language || "Multi-stack",
              status: "completed",
              priority: "low"
            },
            {
              id: `${repo.id}-2`,
              title: "Last Deployment",
              description: new Date(repo.updated_at).toLocaleDateString(),
              status: "completed",
              priority: "low"
            }
          ]
        });

        setKarlRepos(karlData.map(transform));
        setJhanricRepos(jhanricData.map(transform));
      } catch (error) {
        console.error("Error fetching repos:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchRepos();
  }, []);

  return (
    <main ref={containerRef} className="min-h-screen pt-60 pb-80 px-6 relative overflow-hidden">
      <BackgroundChassis />
      
      <div className="max-w-7xl mx-auto relative z-10 space-y-60">
        <motion.div style={{ opacity, y: y1 }} className="mb-40 text-center border-b-bionic border-ink-dark pb-40">
          <h2 className="text-bionic-heading text-ink-dark">
            <span className="text-selected-dark px-12">REPOSITORY</span> <br /> <span className="text-selected-red px-12 mt-4 inline-block">ARCHIVE</span>
          </h2>
          <div className="border-l-[8px] border-accent-red pl-8 mt-12 max-w-2xl mx-auto">
            <div className="bg-box-gray">
              <p className="text-bionic-label text-ink-dark text-left leading-relaxed font-black">
                 Live synchronization with GitHub development clusters. <br />
                 Accessing core repositories for system initialization.
              </p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 lg:gap-32">
          {/* Karl's Column */}
          <motion.div style={{ y: y2 }} transition={{ duration: 0.4 }} className="space-y-12">
             <div className="flex items-center gap-8 mb-8">
                <div className="w-20 h-20 bg-ink-dark flex items-center justify-center text-surface border-bionic shadow-bionic transition-none">
                   <Code2 size={32} />
                </div>
                <div>
                   <h4 className="text-4xl font-asix font-black text-ink-dark uppercase tracking-tighter leading-none">Karl&apos;s Lab</h4>
                   <p className="text-selected-red font-asix text-[12px] font-black tracking-widest mt-2 px-2">SYSTEMS_ENGINEER</p>
                </div>
             </div>
             
             {loading ? (
                <div className="h-[600px] border-bionic bg-ink-dark/5 animate-pulse" />
             ) : (
                <AgentPlan initialTasks={karlRepos} />
             )}
          </motion.div>

          {/* Jhanric's Column */}
          <motion.div style={{ y: y1 }} transition={{ duration: 0.4 }} className="space-y-12 lg:mt-40">
             <div className="flex items-center gap-8 mb-8">
                <div className="w-20 h-20 bg-surface border-bionic shadow-bionic-accent flex items-center justify-center text-ink-dark transition-none">
                   <Sparkles size={32} />
                </div>
                <div>
                   <h4 className="text-4xl font-asix font-black text-ink-dark uppercase tracking-tighter leading-none">Jhanric&apos;s Atelier</h4>
                   <p className="text-selected-red font-asix text-[12px] font-black tracking-widest mt-2 px-2">CREATIVE_VISIONARY</p>
                </div>
             </div>

             {loading ? (
                <div className="h-[600px] border-bionic bg-ink-dark/5 animate-pulse" />
             ) : (
                <AgentPlan initialTasks={jhanricRepos} />
             )}
          </motion.div>
        </div>
      </div>
    </main>
  );
}
