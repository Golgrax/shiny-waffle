"use client";
import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { duoInfo } from "@/lib/data";
import { Mail, MessageSquare } from "lucide-react";
import { GithubIcon, PayPalIcon } from "@/components/icons";
import { BackgroundChassis } from "@/components/ui/background-chassis";

export default function ContactPage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"],
  });

  const y1 = useTransform(scrollYProgress, [0, 1], [0, -100]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, 100]);
  const opacity = useTransform(scrollYProgress, [0, 0.1, 0.9, 1], [1, 1, 1, 0]);

  return (
    <main ref={containerRef} className="min-h-screen relative overflow-hidden pt-60 pb-80 px-6">
      <BackgroundChassis />

      <div className="relative z-10 max-w-5xl mx-auto flex flex-col items-center justify-center space-y-40">
        <motion.div style={{ opacity, y: y1 }} transition={{ duration: 0.4 }} className="w-full">
          <div className="text-center mb-24 border-b-bionic border-ink-dark pb-20">
            <motion.h2 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-bionic-heading text-ink-dark"
            >
              <span className="text-selected-dark px-12">CONNECT</span> <br /> <span className="text-selected-red px-12 mt-4 inline-block">ARCHITECTS</span>
            </motion.h2>
            <div className="bg-box-gray mt-12 max-w-2xl mx-auto">
              <p className="text-bionic-label text-ink-dark">
                Establish direct link with the core units
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <ContactCard 
              icon={<Mail size={24} />}
              title="DIRECT_EMAIL"
              value={duoInfo.karl.email}
              href={`mailto:${duoInfo.karl.email}`}
            />
            <ContactCard 
              icon={<GithubIcon size={24} />}
              title="SOURCE_CONTROL"
              value="GitHub Profiles"
              href="https://github.com/Golgrax"
            />
            <ContactCard 
              icon={<MessageSquare size={24} />}
              title="ECOSYSTEM"
              value="Discord Link"
              href="#"
            />
            <ContactCard 
              icon={<PayPalIcon size={24} />}
              title="SPONSORSHIP"
              value="Support Work"
              href={duoInfo.karl.socials.paypal}
            />
          </div>
        </motion.div>

        <motion.div 
          style={{ y: y2 }}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.4 }}
          className="w-full border-bionic bg-surface shadow-bionic p-8 md:p-16 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-caution-stripes opacity-10 -rotate-45 translate-x-16 -translate-y-16" />
          
          <div className="relative z-10">
             <div className="flex items-center gap-6 mb-12 border-b-4 border-ink-dark pb-8">
                <div className="w-12 h-12 bg-accent-red" />
                <h4 className="text-3xl font-black text-ink-dark uppercase font-asix tracking-widest">Transmit_Signal</h4>
             </div>
             
             <form className="space-y-12">
                <div className="bg-box-gray">
                   <label className="block text-bionic-label text-accent-red mb-4 font-black">Subject_ID</label>
                   <input className="w-full bg-surface border-bionic border-ink-dark/20 p-4 outline-none focus:border-accent-red transition-colors font-asix uppercase text-lg" placeholder="Project collaboration..." />
                </div>
                
                <div className="bg-box-gray">
                   <label className="block text-bionic-label text-accent-red mb-4 font-black">Message_Payload</label>
                   <textarea className="w-full bg-surface border-bionic border-ink-dark/20 p-4 outline-none focus:border-accent-red transition-colors font-asix uppercase text-lg resize-none" rows={6} placeholder="Type your message here..." />
                </div>
                
                <button 
                   type="button"
                   className="w-full bionic-button"
                >
                   Execute_Transmission
                </button>
             </form>
          </div>
        </motion.div>
      </div>
    </main>
  );
}

function ContactCard({ icon, title, value, href }: { icon: React.ReactNode, title: string, value: string, href: string }) {
  return (
    <motion.a 
      href={href}
      target="_blank"
      className="p-8 border-bionic bg-surface shadow-bionic flex items-center gap-8 group"
    >
      <div className="w-16 h-16 bg-ink-dark flex items-center justify-center text-surface transition-none">
        {icon}
      </div>
      <div>
        <p className="text-highlight-red text-[10px] mb-2 font-black">{title}</p>
        <p className="text-ink-dark font-black text-lg tracking-tight font-asix">{value}</p>
      </div>
    </motion.a>
  );
}
