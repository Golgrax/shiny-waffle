"use client";
import React, { useRef } from "react";
import { motion } from "framer-motion";
import { ContainerScroll } from "@/components/ui/container-scroll-animation";
import { LinkPreview } from "@/components/ui/link-preview";
import { duoInfo } from "@/lib/data";
import Image from "next/image";
import { BackgroundChassis } from "@/components/ui/background-chassis";

export default function Home() {
  const scrollRef = useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const el = scrollRef.current;
    if (el) {
      const onWheel = (e: WheelEvent) => {
        if (e.deltaY === 0) return;
        
        const isScrollingLeft = e.deltaY < 0;
        const isScrollingRight = e.deltaY > 0;
        const canScrollLeft = el.scrollLeft > 0;
        const canScrollRight = el.scrollLeft + el.clientWidth < el.scrollWidth - 1;

        if ((isScrollingLeft && canScrollLeft) || (isScrollingRight && canScrollRight)) {
          el.scrollTo({
            left: el.scrollLeft + e.deltaY * 2,
            behavior: "auto",
          });
          e.preventDefault();
        }
      };
      el.addEventListener("wheel", onWheel, { passive: false });
      return () => el.removeEventListener("wheel", onWheel);
    }
  }, []);

  return (
    <main className="relative min-h-screen w-full overflow-x-hidden pt-20">
      <BackgroundChassis />

      <div className="flex flex-col overflow-hidden pt-20 md:pt-40 relative z-10">
        <ContainerScroll
          titleComponent={
            <div className="flex flex-col items-center justify-center py-20">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.1 }}
                className="flex items-center gap-6 md:gap-12 mb-16"
              >
                <div className="relative w-24 h-24 md:w-40 md:h-40 border-bionic shadow-bionic bg-surface overflow-hidden">
                  <Image src={duoInfo.karl.avatar} alt="Karl" fill sizes="(max-width: 768px) 96px, 160px" className="object-cover grayscale" />
                </div>
                
                <div className="h-20 w-4 md:h-32 md:w-8 bg-caution-stripes border-[4px] border-ink-dark shadow-bionic -rotate-12" />
                
                <div className="relative w-24 h-24 md:w-40 md:h-40 border-bionic shadow-bionic-accent bg-surface overflow-hidden">
                  <Image src={duoInfo.jhanric.avatar} alt="Jhanric" fill sizes="(max-width: 768px) 96px, 160px" className="object-cover grayscale" />
                </div>
              </motion.div>

              <h1 className="text-bionic-heading text-ink-dark text-center leading-[0.8] mb-12 whitespace-nowrap">
                <LinkPreview url={duoInfo.karl.socials.github} className="inline-block"><span className="text-selected-dark px-4">KARL</span></LinkPreview>
                <br />
                <span className="text-selected-red px-6 my-6 inline-block font-asix text-4xl md:text-5xl lg:text-6xl">&</span>
                <br />
                <LinkPreview url={duoInfo.jhanric.socials.github} className="inline-block"><span className="text-selected-dark px-4">JHANRIC</span></LinkPreview>
              </h1>
              
              <div className="border-l-[8px] border-accent-red pl-8 mb-20 max-w-2xl">
                <div className="bg-box-gray !my-0">
                  <p className="text-bionic-label text-ink-dark text-left leading-relaxed font-black">
                    Bionic design 2026. All rights reserved. <br />
                    Merging <span className="text-selected-red px-2">Engineered Logic</span> <span className="text-ink-dark/20 mx-1">×</span> <span className="text-selected-dark px-2">Cinematic Interfaces</span>. <br />
                    V01. Focus-07.
                  </p>
                </div>
              </div>
            </div>
          }
        >
          <div className="relative w-full h-full min-h-[35rem] bg-surface border-bionic flex flex-col items-center justify-center p-8 md:p-16 group shadow-bionic overflow-visible">
             <div className="absolute top-0 right-0 w-24 h-24 bg-caution-stripes opacity-10 -rotate-45 translate-x-12 -translate-y-12" />
             
             <div className="z-10 text-center max-w-3xl">
                <h3 className="text-2xl md:text-4xl lg:text-5xl font-black text-ink-dark mb-8 tracking-[0.1em] leading-[0.85] uppercase whitespace-nowrap">THE MODERN <br /> <span className="text-selected-red px-6">DUO UNIT</span></h3>
                <div className="border-t-[4px] border-ink-dark pt-8">
                  <div className="bg-box-gray">
                    <p className="text-ink-dark font-asix text-sm md:text-lg max-w-2xl mx-auto leading-tight font-black uppercase tracking-[0.05em]">
                       Specializing in high-performance systems and immersive user experiences. <br />
                       Pushing boundaries through mathematical precision and artistic vision.
                    </p>
                  </div>
                </div>
             </div>
          </div>
        </ContainerScroll>
      </div>

      <section className="relative z-10 w-full min-h-screen py-40 px-12">
        <div className="max-w-[100vw] overflow-x-auto no-scrollbar" ref={scrollRef}>
          <div className="flex items-center gap-12 min-w-max pb-40 px-20">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4 }}
              className="space-y-10 max-w-xl"
            >
              <h2 className="text-bionic-heading text-ink-dark whitespace-nowrap leading-[0.75] tracking-[0.1em]">
                THE <br /> <span className="text-selected-red px-8">SYNERGY</span>
              </h2>
              <div className="border-l-[8px] border-ink-dark pl-8">
                <div className="bg-box-gray !p-6">
                  <p className="text-lg md:text-xl font-asix text-ink-dark leading-tight font-black uppercase tracking-[0.05em]">
                    We create digital ecosystems where backend precision meets frontend elegance. <br />
                    Bridging the gap between machine logic and human experience.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-24 h-6 bg-caution-stripes border-2 border-ink-dark shadow-bionic" />
                <div className="w-8 h-6 bg-accent-red border-2 border-ink-dark shadow-bionic" />
              </div>
            </motion.div>

            <div className="flex gap-8 h-full py-10">
              <ParallaxCard delay={0.05} title="System" desc="Low-level AI" color="accent" />
              <ParallaxCard delay={0.1} title="Chassis" desc="Cinematic UX" color="dark" />
              <ParallaxCard delay={0.15} title="Flow" desc="Interactivity" color="dark" />
              <ParallaxCard delay={0.2} title="Module" desc="Optimization" color="dark" />
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

function ParallaxCard({ title, desc, delay, color }: { title: string, desc: string, delay: number, color: string }) {
  const colors: Record<string, string> = {
    accent: "shadow-bionic-accent",
    dark: "shadow-bionic",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.3 }}
      className={`group p-8 border-bionic bg-surface transition-none min-w-[350px] ${colors[color]}`}
    >
      <h3 className="text-2xl md:text-3xl font-black text-ink-dark mb-4 uppercase leading-none tracking-[0.1em]">{title}</h3>
      <div className="bg-box-gray !p-4">
        <p className="text-[10px] md:text-xs font-black text-ink-dark/80 uppercase tracking-widest">{desc}</p>
      </div>
      <div className="mt-8 h-2 w-full bg-ink-dark/10 transition-none border-t border-ink-dark/5" />
    </motion.div>
  );
}
