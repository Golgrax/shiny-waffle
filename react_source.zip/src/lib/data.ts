export const duoInfo = {
  karl: {
    name: "Karl Benjamin",
    fullName: "Karl Benjamin R. Bughaw",
    alias: ["Golgrax", "Alias Kulay", "Ben", "Ben'ji"],
    role: "System Architect & Backend Specialist",
    bio: "A visionary software engineer specializing in neural architectures and high-performance decision systems. Focused on building practical applications that solve complex real-world challenges with elegant, low-level logic.",
    location: "Southeast Asia",
    email: "benjo@pro.space",
    avatar: "https://avatars.githubusercontent.com/u/70707230?v=4",
    skills: {
      languages: ["Python", "Rust", "Lua/Luau", "C/C++", "Java", "TypeScript", "SQL", "Bash"],
      frameworks: ["Syqlorix", "Node.js", "React", "Flask", "TensorFlow", "PyTorch", "NumPy", "YOLO"],
      tools: ["Docker", "Git", "Ghidra", "Vim", "Roblox Studio", "Figma", "MX Linux", "Debian"]
    },
    socials: {
      github: "https://github.com/Golgrax",
      twitter: "https://x.com/BughawBenjo",
      linkedin: "https://linkedin.com/in/karl-benjamin-r-bughaw",
      discord: "Golgrax",
      paypal: "https://paypal.me/KarlBughaw"
    }
  },
  jhanric: {
    name: "Jhanric",
    fullName: "Jhanric Hanamichi C. Pablo",
    alias: ["jhanric-pablo"],
    role: "Creative Developer & UI/UX Specialist",
    bio: "A creative developer dedicated to cinematic web design and immersive user experiences. Merging high-performance frontend logic with aesthetic excellence to create websites that feel alive and responsive.",
    location: "Philippines",
    avatar: "https://avatars.githubusercontent.com/u/234446052?v=4",
    skills: {
      languages: ["TypeScript", "JavaScript", "Rust", "C++", "Python", "HTML5", "CSS3"],
      frameworks: ["Next.js", "Tailwind CSS", "Vue.js", "Three.js", "Framer Motion"],
      tools: ["Xcode", "WooCommerce", "GitHub", "Figma", "Slack", "Discord"]
    },
    socials: {
      github: "https://github.com/jhanric-pablo",
      spotify: "https://open.spotify.com/user/31u4gn2tafxrizo67brnc27nogfy",
      discord: "Discord",
      instagram: "Instagram"
    }
  }
};

export const projects = [
  {
    name: "Syqlorix",
    description: "A high-performance, hyper-minimalist hybrid web framework for Python. Combines pure Python DSL with a Rust-powered core for maximum throughput.",
    url: "https://github.com/Syqlorix/Syqlorix",
    language: "Python / Rust",
    stars: 19
  },
  {
    name: "Kawayan",
    description: "Intelligent content engine for Philippine MSMEs. Automates social media management with localized 'Taglish' AI content generation.",
    url: "https://github.com/Golgrax/Kawayan",
    language: "Python",
    stars: 5
  },
  {
    name: "Elyth",
    description: "Create Discord bots in Python with dead-simple, string-based commands. Focuses on speed and developer experience.",
    url: "https://github.com/ElythHQ/Elyth",
    language: "Python",
    stars: 1
  },
  {
    name: "ModernMe",
    description: "A high-performance, animated portfolio remake featuring modern UI trends, glassmorphism, and interactive elements.",
    url: "https://github.com/Golgrax/ModernMe",
    language: "TypeScript",
    stars: 0
  },
  {
    name: "GyroUI",
    description: "A specialized UI component library focusing on motion and responsiveness for high-end web applications.",
    url: "https://github.com/jhanric-pablo/GyroUI",
    language: "TypeScript",
    stars: 2
  }
];

