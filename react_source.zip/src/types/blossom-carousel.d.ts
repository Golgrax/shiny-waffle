declare module "@blossom-carousel/react" {
  import { ReactNode, ForwardRefExoticComponent, RefAttributes, HTMLAttributes, ElementType } from "react";

  export interface BlossomCarouselHandle {
    prev: (options?: { align?: string }) => void;
    next: (options?: { align?: string }) => void;
    element: HTMLElement | null;
  }

  export interface BlossomCarouselProps extends HTMLAttributes<HTMLElement> {
    children?: ReactNode | Array<ReactNode>;
    as?: ElementType;
    repeat?: boolean;
    load?: "always" | "conditional";
  }

  export const BlossomCarousel: ForwardRefExoticComponent<
    BlossomCarouselProps & RefAttributes<BlossomCarouselHandle>
  >;
}
